const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const session = require("express-session");
const cors = require("cors");
const path = require("path");
const passport = require('passport');
const fileUpload = require('express-fileupload');
const expressValidator = require('express-validator');
const app = express();



const fetch = require('node-fetch');





app.get('/rapidapi', function (req, res) {


  res.render('footballliveAPI.ejs');
})




// const customValidators = require('custom-validator');


require("dotenv").config();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(require('connect-flash')());
app.use(function (req, res, next) {
  res.locals.messages = require('express-messages')(req, res);
  next();
})

app.use(fileUpload());

app.use(session({
  secret: 'keyboard cat',
  resave: true,
  saveUninitialized: true,
  //cookie: {secure: true}
}));

app.use(expressValidator({
  errorFormatter: function (parm, msg, value) {
    var namespace = parm.split(','),
      root = namespace.shift(),
      formParam = root;

    while (namespace.length) {
      formParam += '[' + namespace.shift() + ']';
    }

    return {
      param: formParam,
      msg: msg,
      value: value
    };
  },
  customValidators: {
    isImage: function (value, filename) {
      var extension = (path.extname(filename)).toLowerCase();
      switch (extension) {
        case '.jpg':
          return '.jpg';
        case '.jpeg':
          return '.jpeg';
        case '.png':
          return '.png';
        case '':
          return '.jpg';
        default:
          return false;
      }
    }
  },

}));

var Page = require('./models/page');

Page.find({}).sort({ sorting: 1 }).exec(function (err, pages) {
  if (err) {
    console.log(err);
  } else {
    app.locals.pages = pages;
  }


});

var Category = require('./models/category');

Category.find(function (err, categories) {
  if (err) {
    console.log(err);
  } else {
    app.locals.categories = categories;
  }


});

app.use(express.static(path.join(__dirname, 'public')));
// database init
mongoose
  .connect(process.env.MONGODB_API, {
    useUnifiedTopology: true,
    useNewUrlParser: true,
    useCreateIndex: true,
  })
  .then(() => {
    console.log("connected to database...");
  })
  .catch(() => {
    console.log("failed connected to database");
  });

// // Routes
// const userRoutes = require("./routes/user");

// Middlewares
app.use(bodyParser.json());
app.use(cors());

// // Routes
// app.use("/api", userRoutes);
//const userRoutes = require("./views/layouts/header");
// app.get("/", (req, res) => {
//   res.render('header');
// });
app.locals.errors = null;
var pages = require('./routes/pages.js');
var products = require('./routes/products.js');
var cart = require('./routes/cart.js');
var users = require('./routes/users.js');
var adminpages = require('./routes/adminPage.js');
var adminCategories = require('./routes/admincategories.js');
var adminProducts = require('./routes/admin_products.js');
const { json } = require("body-parser");
app.use('/products', products);
app.use('/cart', cart);
app.use('/users', users);
app.use('/', pages);
app.use('/admin/pages', adminpages);
app.use('/admin/categories', adminCategories);
app.use('/admin/products', adminProducts);
// PORT
require('./config/passport')(passport);
app.use(passport.initialize());
app.use(passport.session());

app.get('*', function (req, res, next) {
  res.locals.cart = req.session.cart;
  res.locals.user = req.user || null;
  next();
});

const port = process.env.PORT || 5000;

// Starting a server
app.listen(port, () => {
  console.log(`app is running at ${port}`);
});
