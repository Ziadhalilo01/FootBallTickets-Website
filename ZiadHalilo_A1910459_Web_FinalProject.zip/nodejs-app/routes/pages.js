var express = require('express');
var router = express.Router();
var Page = require('../models/page');

router.get('/',function(req,res) {
    Page.findOne({slug: 'home'},function(err,page){
        if(err) throw err;

       else{
            res.render('header',{
                title: page.title,
                content: page.content

            });
        }
    });
});



router.get('/:slug',function(req,res) {
    var slug = req.params.slug;
    Page.findOne({slug: slug},function(err,page){
        if(err) throw err;

        if(!page){
            res.redirect('/');
        }else{
            res.render('header',{
                title: page.title,
                content: page.content

            });
        }
    });
    // res.render('header',{
    //     title: 'Home'
    // });
});



module.exports = router;