var express = require('express');
var router = express.Router();
var fs = require('fs-extra');
var Product = require('../models/product');
var Category = require('../models/category');


router.get('/', function (req, res) {
    Product.find(function (err, products) {
        if (err) throw err;


        res.render('all_products', {
            title: 'All products',
            products: products

        });

    });
});



router.get('/:category', function (req, res) {

    var categorySlug = req.params.category;
    Category.findOne({ slug: categorySlug }, function (err, c) {
        Product.find({category: categorySlug},function (err, products) {
            if (err) throw err;


            res.render('cat_products', {
                title: c.title,
                products: products

            });

        });

    });

});


router.get('/:category/:product', function (req, res) {
    var galleryImages = null;
    Product.findOne({slug: req.params.product}, function(err,product){
        if(err){
            console.log(err);
        }else{
            var galleryDir = 'public/product_images/' + product._id + '/gallery';
            fs.readdir(galleryDir,function(err,files){
                if(err) throw err;

                else{
                    galleryImages = files;

                    res.render('product',{
                        title: product.title,
                        p: product,
                        galleryImages: galleryImages

                    })
                }

            });
        }



    });

  

});



// router.get('/:slug', function (req, res) {
//     var slug = req.params.slug;
//     Page.findOne({ slug: slug }, function (err, page) {
//         if (err) throw err;

//         if (!page) {
//             res.redirect('/');
//         } else {
//             res.render('header', {
//                 title: page.title,
//                 content: page.content

//             });
//         }
//     });
//     // res.render('header',{
//     //     title: 'Home'
//     // });
// });



module.exports = router;